# DSCI-552-HW
This repository is the homework collection of the course DSCI 552 (USC 2020 Fall), including the raw implementation of various machine learning algorithms. Feel free to contact me if you have any questions to the code details.
