# INF-552
Author: Nelson Lam
email: szechitl@usc.edu

This repository is created for HW submission for INF - 552 (Machine Learning for Data Science). \
Homework code and reports are contained in the Homework folder.
